package basne3.Config;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class TestConnection {
    public static void main(String[] args) {
        String url = "jdbc:mysql://127.0.0.1:3306/basne3?connectTimeout=3000&socketTimeout=3000";
        String user = "root";
        String password = "Ulum19052005";

        try {
            System.out.println("Mencoba koneksi ke database...");
            Connection conn = DriverManager.getConnection(url, user, password);
            System.out.println("✅ Koneksi berhasil!");
            conn.close();
        } catch (SQLException e) {
            System.out.println("❌ Koneksi gagal!");
            e.printStackTrace(); // <-- tampilkan error detail
        }
    }
}



/**
 *
 * @author septi
 */
